import grid

grid.createprecomputedindicesjson()

